import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Employee {
  employeeId?: number;
  employeeName: string;
  employeeEmail: string;
  employeePhone: number;
  employeeDesignation: string;
  employeeAddress: string;
  employeeSalary: number;
  employeeGrade: string;
  employeePassword?: string;
}

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private baseUrl = 'http://localhost:8080'; // Spring Boot backend

  constructor(private http: HttpClient) {}

  createEmployee(employee: Employee): Observable<Employee> {
    return this.http.post<Employee>(`${this.baseUrl}/signup`, employee);
  }

  getAllEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.baseUrl}/find/all`);
  }

  getEmployeeById(employeeId: number): Observable<Employee> {
    return this.http.get<Employee>(`${this.baseUrl}/find?employeeId=${employeeId}`);
  }

  updateEmployee(employeeId: number, employee: Employee): Observable<Employee> {
    return this.http.put<Employee>(`${this.baseUrl}/update?employeeId=${employeeId}`, employee);
  }

  deleteEmployee(employeeId: number): Observable<Employee> {
    return this.http.delete<Employee>(`${this.baseUrl}/delete/id?employeeId=${employeeId}`);
  }

  loginEmployee(employeeEmail: string, employeePassword: string): Observable<string> {
    return this.http.get(`${this.baseUrl}/login?employeeEmail=${employeeEmail}&employeePassword=${employeePassword}`, { responseType: 'text' });
  }
}
