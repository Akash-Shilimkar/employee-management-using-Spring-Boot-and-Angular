import { Routes } from '@angular/router';
import { EmployeeList } from './components/employee-list/employee-list';
import { EmployeeForm } from './components/employee-form/employee-form';
import { EmployeeUpdate } from './components/employee-update/employee-update';
import { EmployeeDetails } from './components/employee-details/employee-details';

export const appRoutes: Routes = [
  { path: '', redirectTo: 'employees', pathMatch: 'full' },
  { path: 'employees', component: EmployeeList },
  { path: 'add-employee', component: EmployeeForm },
  { path: 'update-employee/:id', component: EmployeeUpdate },
  { path: 'employee-details/:id', component: EmployeeDetails }
];
