import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { EmployeeService, Employee } from '../../Services/employee-service';

@Component({
  selector: 'app-employee-details',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './employee-details.html',
  styleUrls: ['./employee-details.scss']
})
export class EmployeeDetails implements OnInit {
  employeeId!: number;
  employee?: Employee;

  constructor(private route: ActivatedRoute, private service: EmployeeService) {}

  ngOnInit() {
    this.employeeId = Number(this.route.snapshot.paramMap.get('id'));
    this.service.getEmployeeById(this.employeeId).subscribe(data => this.employee = data);
  }
}
