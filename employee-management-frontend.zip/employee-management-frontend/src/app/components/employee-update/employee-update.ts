import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService, Employee } from '../../Services/employee-service';

@Component({
  selector: 'app-employee-update',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './employee-update.html',
  styleUrls: ['./employee-update.scss']
})
export class EmployeeUpdate implements OnInit {
  employeeId!: number;
  employee: Employee = {
    employeeName: '',
    employeeEmail: '',
    employeePhone: 0,
    employeeDesignation: '',
    employeeAddress: '',
    employeeSalary: 0,
    employeeGrade: ''
  };

  constructor(private route: ActivatedRoute, private service: EmployeeService, private router: Router) {}

  ngOnInit() {
    this.employeeId = Number(this.route.snapshot.paramMap.get('id'));
    this.service.getEmployeeById(this.employeeId).subscribe(data => this.employee = data);
  }

  onUpdate() {
    this.service.updateEmployee(this.employeeId, this.employee).subscribe(() => {
      alert('Employee updated successfully!');
      this.router.navigate(['/employees']);
    });
  }
}
