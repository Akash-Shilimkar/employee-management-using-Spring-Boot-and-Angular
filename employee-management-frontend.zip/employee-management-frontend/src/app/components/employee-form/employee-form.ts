import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Employee, EmployeeService } from '../../Services/employee-service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee-form',
  standalone: true,
  templateUrl: './employee-form.html',
  styleUrls: ['./employee-form.scss'],
  imports: [FormsModule, CommonModule]
})
export class EmployeeForm {
  employee: Employee = {
    employeeName: '',
    employeeEmail: '',
    employeePhone: 0,
    employeeSalary: 0,
    employeeGrade: '',
    employeeDesignation: '',
    employeeAddress: ''
  };

  constructor(private employeeService: EmployeeService, private router: Router) {}

  onSubmit() {
    this.employeeService.createEmployee(this.employee).subscribe(() => {
      alert('Employee added successfully!');
      this.router.navigate(['/employees']);
    });
  }
}
